#!/usr/bin/env bash

python ae_train.py
    --num-games 10000 \
    --num-gpus 1 \
    --epochs 1 \
